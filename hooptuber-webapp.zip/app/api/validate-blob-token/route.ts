import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const token = process.env.BLOB_READ_WRITE_TOKEN

    const validation = {
      tokenExists: !!token,
      tokenLength: token?.length || 0,
      tokenFormat: token?.startsWith("vercel_blob_rw_") || false,
      tokenPrefix: token?.substring(0, 25) || "none",
      environment: {
        nodeEnv: process.env.NODE_ENV,
        vercelEnv: process.env.VERCEL_ENV,
      },
    }

    console.log("Token validation:", validation)

    if (!token) {
      return NextResponse.json({
        valid: false,
        error: "BLOB_READ_WRITE_TOKEN not found",
        validation,
        recommendation: "Add BLOB_READ_WRITE_TOKEN to your .env.local file",
      })
    }

    if (!token.startsWith("vercel_blob_rw_")) {
      return NextResponse.json({
        valid: false,
        error: "Invalid token format",
        validation,
        recommendation: "Token should start with 'vercel_blob_rw_'",
      })
    }

    // Test the token with a minimal operation
    try {
      const { put } = await import("@vercel/blob")

      const testData = `token-test-${Date.now()}`
      const testFileName = `token-validation/test-${Date.now()}.txt`

      const blob = await put(testFileName, testData, {
        access: "public",
        addRandomSuffix: false,
      })

      // Clean up
      try {
        const { del } = await import("@vercel/blob")
        await del(blob.url)
      } catch (cleanupError) {
        console.warn("Cleanup failed:", cleanupError)
      }

      return NextResponse.json({
        valid: true,
        message: "Token is working correctly",
        validation,
        testResult: {
          success: true,
          testUrl: blob.url,
        },
      })
    } catch (testError: any) {
      console.error("Token test failed:", testError)

      return NextResponse.json({
        valid: false,
        error: "Token test failed",
        validation,
        testError: {
          message: testError.message,
          type: testError.name,
        },
        recommendation: "Get a fresh token from Vercel Dashboard → Storage → Blob",
      })
    }
  } catch (error) {
    return NextResponse.json(
      {
        valid: false,
        error: "Validation failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
